package com.allhack.cheats;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class LoginActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.parseColor("#0D0D0D"));
        layout.setPadding(50, 50, 50, 50);
        layout.setGravity(Gravity.CENTER);

        TextView title = new TextView(this);
        title.setText("Bradesco");
        title.setTextColor(Color.WHITE);
        title.setTextSize(32);
        layout.addView(title);

        final EditText etName = new EditText(this);
        etName.setHint("Coloque seu nome");
        etName.setTextColor(Color.WHITE);
        etName.setHintTextColor(Color.GRAY);
        layout.addView(etName);

        Button btn = new Button(this);
        btn.setText("Entrar");
        btn.setBackgroundColor(Color.parseColor("#C62828"));
        btn.setTextColor(Color.WHITE);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, MainActivity.class));
                finish();
            }
        });
        layout.addView(btn);
        setContentView(layout);
    }
}