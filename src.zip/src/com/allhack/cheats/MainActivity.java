package com.allhack.cheats;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "DÊ PERMISSÃO DE SOBREPOSIÇÃO!", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 123);
                return;
            }
        }
        IniciarTudo();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 123) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this)) {
                    IniciarTudo();
                } else {
                    Toast.makeText(this, "SEM PERMISSÃO, O MENU NÃO VAI ABRIR!", Toast.LENGTH_LONG).show();
                    finish();
                }
            }
        }
    }

    private void IniciarTudo() {
        startService(new Intent(this, FloatingService.class));
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.dts.freefiremax");
        if (launchIntent != null) {
            Toast.makeText(this, "ABRINDO FREE FIRE MAX...", Toast.LENGTH_SHORT).show();
            startActivity(launchIntent);
        } else {
            Intent ffNormal = getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
            if (ffNormal != null) {
                Toast.makeText(this, "ABRINDO FREE FIRE NORMAL...", Toast.LENGTH_SHORT).show();
                startActivity(ffNormal);
            } else {
                Toast.makeText(this, "FREE FIRE NÃO INSTALADO!", Toast.LENGTH_LONG).show();
            }
        }
        finish();
    }
}