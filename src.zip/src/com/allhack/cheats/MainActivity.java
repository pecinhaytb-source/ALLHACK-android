package com.allhack.cheats;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQ = 123;
    private static final int NOTIF_REQ = 101;
    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        // Permissão de notificação pro Android 13+ não matar o app
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF_REQ);
            }
        }

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.parseColor("#0D0D0D"));
        layout.setPadding(50, 50, 50, 50);

        tvStatus = new TextView(this);
        tvStatus.setText("ROOT não verificado");
        tvStatus.setTextColor(Color.GRAY);
        layout.addView(tvStatus);

        Button btnRoot = new Button(this);
        btnRoot.setText("AUTORIZAR ROOT");
        btnRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Runtime.getRuntime().exec("su -c id");
                    tvStatus.setText("ROOT conectado");
                    tvStatus.setTextColor(Color.GREEN);
                } catch (Exception e) {
                    tvStatus.setText("ROOT não encontrado");
                    tvStatus.setTextColor(Color.RED);
                }
            }
        });
        layout.addView(btnRoot);

        Button btnFloat = new Button(this);
        btnFloat.setText("ABRIR FLUTUANTE");
        btnFloat.setBackgroundColor(Color.parseColor("#C62828"));
        btnFloat.setTextColor(Color.WHITE);
        btnFloat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Checa permissão de overlay
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, 
                        Uri.parse("package:" + getPackageName())), OVERLAY_REQ);
                } else {
                    startService(new Intent(MainActivity.this, FloatingService.class));
                    finish();
                }
            }
        });
        layout.addView(btnFloat);
        setContentView(layout);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent d) {
        if (req == OVERLAY_REQ && Settings.canDrawOverlays(this)) {
            startService(new Intent(this, FloatingService.class));
            finish();
        }
    }
}