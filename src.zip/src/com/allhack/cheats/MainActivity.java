package com.allhack.cheats;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Verifica se tem permissão pra desenhar por cima dos outros apps
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "DÊ PERMISSÃO DE SOBREPOSIÇÃO!", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 123);
                return; // Para aqui e espera o usuário dar a permissão
            }
        }

        // Se já tem permissão, inicia o serviço
        IniciarServico();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 123) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this)) {
                    IniciarServico(); // Permissão concedida, inicia
                } else {
                    Toast.makeText(this, "SEM PERMISSÃO, O MENU NÃO VAI ABRIR!", Toast.LENGTH_LONG).show();
                    finish();
                }
            }
        }
    }

    private void IniciarServico() {
        Toast.makeText(this, "SERVIÇO INICIADO!", Toast.LENGTH_SHORT).show();
        startService(new Intent(this, FloatingService.class));
        finish(); // Fecha o app pra ficar só o painel flutuante
    }
}