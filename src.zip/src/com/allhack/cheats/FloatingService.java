package com.allhack.cheats;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;

public class FloatingService extends Service {

    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean isEspRunning = true;

    // O Loop que desenha o ESP
    private final Runnable espLoop = new Runnable() {
        @Override
        public void run() {
            if (!isEspRunning) return;

            // Pega a resolução da tela
            DisplayMetrics dm = getResources().getDisplayMetrics();
            
            // Chama o C++ passando a largura e altura
            NativeBridge.updateESP(dm.widthPixels, dm.heightPixels);

            // Roda de novo daqui a 16ms (aprox 60 FPS)
            handler.postDelayed(this, 16);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("FF_CHEAT", "Serviço iniciado. Preparando injeção...");

        // ==========================================
        // 1. INJEÇÃO AUTOMÁTICA
        // Dispara a injeção furtiva que montamos
        // ==========================================
        NativeBridge.injectStealth(this);

        // ==========================================
        // 2. INICIA O LOOP DO ESP
        // ==========================================
        handler.post(espLoop);

        // ==========================================
        // 3. AQUI VOCÊ CRIA O MENU FLUTUANTE
        // (O WindowManager e os botões vão aqui embaixo)
        // Exemplo:
        // WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        // wm.addView(seuMenuFlutuante, params);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        // Mata o loop se o serviço for fechado
        isEspRunning = false;
        handler.removeCallbacks(espLoop);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}